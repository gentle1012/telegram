// https://127.0.0.1:9001
// https://localhost:9001

const ioServer = require('socket.io');
const RTCMultiConnectionServer = require('rtcmulticonnection-server');
const fs = require('fs');
const express = require('express');
const app = express();
const server = require('https');

var options = {
    key: fs.readFileSync('keys/privatekey.pem'),
    cert: fs.readFileSync('keys/certificate.pem')
};

const port = process.env.PORT || 9001;
var httpServer = server.createServer(options, app);

httpServer.listen(port, process.env.IP || "0.0.0.0", function() {
    console.log('Server is running on port ' + port);
});

// --------------------------
// socket.io codes goes below

ioServer(httpServer).on('connection', function(socket) {
    RTCMultiConnectionServer.addSocket(socket);

    // ----------------------
    // below code is optional

    const params = socket.handshake.query;

    if (!params.socketCustomEvent) {
        params.socketCustomEvent = 'custom-message';
    }

    socket.on(params.socketCustomEvent, function(message) {
        socket.broadcast.emit(params.socketCustomEvent, message);
    });
});

app.use(express.static('public'));
