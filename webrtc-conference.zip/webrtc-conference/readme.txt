node server.js

open webbrowser and goto https://{ipaddr}:9001/
open and join with same room id